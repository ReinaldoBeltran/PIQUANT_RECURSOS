<!DOCTYPE html>
<html lang="en-US">
<head>
<meta charset="UTF-8" />
<link rel="profile" href="https://gmpg.org/xfn/11" />
<link rel="pingback" href="https://piquant.qodeinteractive.com/xmlrpc.php" />
<meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no">
<title>Page not found &#8211; Piquant</title>
<script type="application/javascript">var mkdCoreAjaxUrl = "https://piquant.qodeinteractive.com/wp-admin/admin-ajax.php"</script><script type="application/javascript">var mkdRestaurantAjaxUrl = "https://piquant.qodeinteractive.com/wp-admin/admin-ajax.php"</script>

<script data-cfasync="false" data-pagespeed-no-defer type="text/javascript">//<![CDATA[
	var gtm4wp_datalayer_name = "dataLayer";
	var dataLayer = dataLayer || [];
//]]>
</script>
<link rel='dns-prefetch' href='//export.qodethemes.com' />
<link rel='dns-prefetch' href='//maps.googleapis.com' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="Piquant &raquo; Feed" href="https://piquant.qodeinteractive.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="Piquant &raquo; Comments Feed" href="https://piquant.qodeinteractive.com/comments/feed/" />
<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/piquant.qodeinteractive.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.2.12"}};
			!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])?!1:!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([55357,56424,55356,57342,8205,55358,56605,8205,55357,56424,55356,57340],[55357,56424,55356,57342,8203,55358,56605,8203,55357,56424,55356,57340])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel="stylesheet" href="https://piquant.qodeinteractive.com/wp-content/cache/minify/7de6a.css" media="all" />
<link rel='stylesheet' id='rabbit_css-css' href='https://export.qodethemes.com/_toolbar/assets/css/rbt-modules.css?ver=5.2.12' type='text/css' media='all' />
<link rel="stylesheet" href="https://piquant.qodeinteractive.com/wp-content/cache/minify/c138f.css" media="all" />
<style id='rs-plugin-settings-inline-css' type='text/css'>
#rs-demo-id {}
</style>
<link rel="stylesheet" href="https://piquant.qodeinteractive.com/wp-content/cache/minify/9b38b.css" media="all" />
<link rel='stylesheet' id='mkd_google_fonts-css' href='https://fonts.googleapis.com/css?family=Roboto+Slab%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7COswald%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CShadows+Into+Light%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CRoboto+Slab%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7COswald%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CPacifico%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CAlike%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CMontserrat%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic&#038;subset=latin%2Clatin-ext&#038;ver=1.0.0' type='text/css' media='all' />
<link rel="stylesheet" href="https://piquant.qodeinteractive.com/wp-content/cache/minify/6cae6.css" media="all" />
<!--[if lt IE 9]>
<link rel='stylesheet' id='vc_lte_ie9-css'  href='https://piquant.qodeinteractive.com/wp-content/plugins/js_composer/assets/css/vc_lte_ie9.min.css' type='text/css' media='screen' />
<![endif]-->
<script src="https://piquant.qodeinteractive.com/wp-content/cache/minify/eff97.js"></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_add_to_cart_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/TweenLite.js?wc-ajax=%%endpoint%%","i18n_view_cart":"View Cart","cart_url":"https:\/\/piquant.qodeinteractive.com\/cart\/","is_cart":"","cart_redirect_after_add":"no"};
/* ]]> */
</script>
<script src="https://piquant.qodeinteractive.com/wp-content/cache/minify/f1253.js"></script>
<script type='text/javascript'>
var mejsL10n = {"language":"en","strings":{"mejs.install-flash":"You are using a browser that does not have Flash player enabled or installed. Please turn on your Flash player plugin or download the latest version from https:\/\/get.adobe.com\/flashplayer\/","mejs.fullscreen-off":"Turn off Fullscreen","mejs.fullscreen-on":"Go Fullscreen","mejs.download-video":"Download Video","mejs.fullscreen":"Fullscreen","mejs.time-jump-forward":["Jump forward 1 second","Jump forward %1 seconds"],"mejs.loop":"Toggle Loop","mejs.play":"Play","mejs.pause":"Pause","mejs.close":"Close","mejs.time-slider":"Time Slider","mejs.time-help-text":"Use Left\/Right Arrow keys to advance one second, Up\/Down arrows to advance ten seconds.","mejs.time-skip-back":["Skip back 1 second","Skip back %1 seconds"],"mejs.captions-subtitles":"Captions\/Subtitles","mejs.captions-chapters":"Chapters","mejs.none":"None","mejs.mute-toggle":"Mute Toggle","mejs.volume-help-text":"Use Up\/Down Arrow keys to increase or decrease volume.","mejs.unmute":"Unmute","mejs.mute":"Mute","mejs.volume-slider":"Volume Slider","mejs.video-player":"Video Player","mejs.audio-player":"Audio Player","mejs.ad-skip":"Skip ad","mejs.ad-skip-info":["Skip in 1 second","Skip in %1 seconds"],"mejs.source-chooser":"Source Chooser","mejs.stop":"Stop","mejs.speed-rate":"Speed Rate","mejs.live-broadcast":"Live Broadcast","mejs.afrikaans":"Afrikaans","mejs.albanian":"Albanian","mejs.arabic":"Arabic","mejs.belarusian":"Belarusian","mejs.bulgarian":"Bulgarian","mejs.catalan":"Catalan","mejs.chinese":"Chinese","mejs.chinese-simplified":"Chinese (Simplified)","mejs.chinese-traditional":"Chinese (Traditional)","mejs.croatian":"Croatian","mejs.czech":"Czech","mejs.danish":"Danish","mejs.dutch":"Dutch","mejs.english":"English","mejs.estonian":"Estonian","mejs.filipino":"Filipino","mejs.finnish":"Finnish","mejs.french":"French","mejs.galician":"Galician","mejs.german":"German","mejs.greek":"Greek","mejs.haitian-creole":"Haitian Creole","mejs.hebrew":"Hebrew","mejs.hindi":"Hindi","mejs.hungarian":"Hungarian","mejs.icelandic":"Icelandic","mejs.indonesian":"Indonesian","mejs.irish":"Irish","mejs.italian":"Italian","mejs.japanese":"Japanese","mejs.korean":"Korean","mejs.latvian":"Latvian","mejs.lithuanian":"Lithuanian","mejs.macedonian":"Macedonian","mejs.malay":"Malay","mejs.maltese":"Maltese","mejs.norwegian":"Norwegian","mejs.persian":"Persian","mejs.polish":"Polish","mejs.portuguese":"Portuguese","mejs.romanian":"Romanian","mejs.russian":"Russian","mejs.serbian":"Serbian","mejs.slovak":"Slovak","mejs.slovenian":"Slovenian","mejs.spanish":"Spanish","mejs.swahili":"Swahili","mejs.swedish":"Swedish","mejs.tagalog":"Tagalog","mejs.thai":"Thai","mejs.turkish":"Turkish","mejs.ukrainian":"Ukrainian","mejs.vietnamese":"Vietnamese","mejs.welsh":"Welsh","mejs.yiddish":"Yiddish"}};
</script>
<script src="https://piquant.qodeinteractive.com/wp-content/cache/minify/864c2.js"></script>
<script type='text/javascript'>
/* <![CDATA[ */
var _wpmejsSettings = {"pluginPath":"\/wp-includes\/js\/mediaelement\/","classPrefix":"mejs-","stretching":"responsive"};
/* ]]> */
</script>
<link rel='https://api.w.org/' href='https://piquant.qodeinteractive.com/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://piquant.qodeinteractive.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://piquant.qodeinteractive.com/wp-includes/wlwmanifest.xml" />
<meta name="generator" content="WordPress 5.2.12" />
<meta name="generator" content="WooCommerce 2.4.10" />

<script data-cfasync="false" data-pagespeed-no-defer type="text/javascript">//<![CDATA[
	var dataLayer_content = [];
	dataLayer.push( dataLayer_content );//]]>
</script>
<script data-cfasync="false">//<![CDATA[
(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'//www.googletagmanager.com/gtm.'+'js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-KTQ2BTD');//]]>
</script>

<style type="text/css">  </style><meta name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress." />
<meta name="generator" content="Powered by Slider Revolution 5.1 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." />
<link rel="icon" href="https://piquant.qodeinteractive.com/wp-content/uploads/2015/11/cropped-favicon-150x150.png" sizes="32x32" />
<link rel="icon" href="https://piquant.qodeinteractive.com/wp-content/uploads/2015/11/cropped-favicon-300x300.png" sizes="192x192" />
<link rel="apple-touch-icon-precomposed" href="https://piquant.qodeinteractive.com/wp-content/uploads/2015/11/cropped-favicon-180x180.png" />
<meta name="msapplication-TileImage" content="https://piquant.qodeinteractive.com/wp-content/uploads/2015/11/cropped-favicon-300x300.png" />
<style type="text/css" id="mkdf-custom-css">.mkdf-single-image-hover a {
    position: relative;
}

.mkdf-single-image-hover a:after {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;

    opacity: 0;
    background-color: rgba(5, 5, 5, 0.28);
    transition: opacity 0.3s ease-in-out;
    -webkit-transition: opacity 0.3s ease-in-out;
}

.mkdf-single-image-hover a:hover:after {
    opacity: 1;
}
.mkdf-vertical-align-containers .mkdf-position-center:before, .mkdf-vertical-align-containers .mkdf-position-left:before, .mkdf-vertical-align-containers .mkdf-position-right:before {
margin-right: 0;
}</style><noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript></head>
<body class="error404 mkd-core-1.0 mkd-restaurant-1.0 piquant-ver-1.1 mkdf-smooth-scroll mkdf-header-standard mkdf-sticky-header-on-scroll-up mkdf-default-mobile-header mkdf-sticky-up-mobile-header mkdf-dropdown-default mkdf-top-bar-in-grid mkdf-side-menu-slide-with-content mkdf-width-370 wpb-js-composer js-comp-ver-6.0.5 vc_responsive">
<section class="mkdf-side-menu right">
<div class="mkdf-close-side-menu-holder">
<div class="mkdf-close-side-menu-holder-inner">
<a href="#" target="_self" class="mkdf-close-side-menu">
<span aria-hidden="true" class="icon_close"></span>
</a>
</div>
</div>
<div id="text-9" class="widget mkdf-sidearea widget_text"> <div class="textwidget"><a href="https://piquant.qodeinteractive.com/"><img src="https://piquant.qodeinteractive.com/wp-content/uploads/2015/11/logo-footer.png" alt="logo"></a>
</div>
</div><div id="nav_menu-2" class="widget mkdf-sidearea widget_nav_menu"><div class="menu-sidearea-menu-container"><ul id="menu-sidearea-menu" class="menu"><li id="menu-item-1239" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-1239"><a href="https://piquant.qodeinteractive.com/">Original Home</a></li>
<li id="menu-item-1240" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1240"><a href="https://piquant.qodeinteractive.com/about-us/">About Us</a></li>
<li id="menu-item-1241" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1241"><a href="https://piquant.qodeinteractive.com/meet-the-chefs/">Meet The Chefs</a></li>
<li id="menu-item-1242" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1242"><a href="https://piquant.qodeinteractive.com/our-services/">Our Services</a></li>
<li id="menu-item-1243" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1243"><a href="https://piquant.qodeinteractive.com/shop/">Shop</a></li>
<li id="menu-item-2825" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2825"><a href="https://piquant.qodeinteractive.com/landing/">Landing</a></li>
</ul></div></div><div id="text-8" class="widget mkdf-sidearea widget_text"> <div class="textwidget"><span style="color:#9b9b9b"> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore.</span>
<div class="mkdf-separator-holder clearfix  mkdf-separator-center">
<div class="mkdf-separator" style="border-color: rgba(255,255,255,0.18);width: 100%;border-bottom-width: 1px;margin-top: 20px;margin-bottom: 20px"></div>
</div>
<span style="color:#fff"> FOLLOW US</span>
<span class="mkdf-icon-shortcode normal" style="margin: 0 1px 0 10px" data-hover-color="#fcf033" data-color="#9b9b9b">
<a href="https://www.facebook.com/QodeInteractive/" target="_blank" rel="noopener noreferrer">
<span class="mkdf-image-icon">
<span aria-hidden="true" class="mkdf-icon-font-elegant social_facebook mkdf-icon-element" style="color: #9b9b9b;font-size:12px"></span> </span>
</a>
</span>
<span class="mkdf-icon-shortcode normal" style="margin: 0 1px 0 0" data-hover-color="#fcf033" data-color="#9b9b9b">
<a href="https://twitter.com/QodeInteractive" target="_blank" rel="noopener noreferrer">
<span class="mkdf-image-icon">
<span aria-hidden="true" class="mkdf-icon-font-elegant social_twitter mkdf-icon-element" style="color: #9b9b9b;font-size:12px"></span> </span>
</a>
</span>
<span class="mkdf-icon-shortcode normal" style="margin: 0 0 0 0" data-hover-color="#fcf033" data-color="#9b9b9b">
<a href="https://www.instagram.com/qodeinteractive/" target="_blank" rel="noopener noreferrer">
<span class="mkdf-image-icon">
<span aria-hidden="true" class="mkdf-icon-font-elegant social_instagram mkdf-icon-element" style="color: #9b9b9b;font-size:12px"></span> </span>
</a>
</span>
<span class="mkdf-icon-shortcode normal" style="margin: 0 0 0 0" data-hover-color="#fcf033" data-color="#9b9b9b">
<a href="http://www.tripadvisor.com/" target="_blank" rel="noopener noreferrer">
<span class="mkdf-image-icon">
<i class="mkdf-icon-font-awesome fa fa-tripadvisor mkdf-icon-element" style="color: #9b9b9b;font-size:14px"></i> </span>
</a>
</span>
</div>
</div></section>
<div class="mkdf-wrapper">
<div class="mkdf-wrapper-inner">
<div class="mkdf-top-bar">
<div class="mkdf-grid">
<div class="mkdf-grid-inner clearfix">
<div class="mkdf-vertical-align-containers mkdf-50-50">
<div class="mkdf-position-left">
<div class="mkdf-position-left-inner">
<div id="text-6" class="widget widget_text mkdf-top-bar-widget"> <div class="textwidget"><p>FOLLOW US
<span class="mkdf-icon-shortcode normal" style="margin: 0 15px 0 15px" data-hover-color="#ffffff" data-color="#e6e6e6">
<a href="https://www.facebook.com/QodeInteractive/" target="_blank" rel="noopener noreferrer">
<span class="mkdf-image-icon">
<span aria-hidden="true" class="mkdf-icon-font-elegant social_facebook mkdf-icon-element" style="color: #e6e6e6;font-size:12px"></span> </span>
</a>
</span>
<span class="mkdf-icon-shortcode normal" style="margin: 0 15px 0 0" data-hover-color="#ffffff" data-color="#e6e6e6">
<a href="https://twitter.com/QodeInteractive" target="_blank" rel="noopener noreferrer">
<span class="mkdf-image-icon">
<span aria-hidden="true" class="mkdf-icon-font-elegant social_twitter mkdf-icon-element" style="color: #e6e6e6;font-size:12px"></span> </span>
</a>
</span>
<span class="mkdf-icon-shortcode normal" style="margin: 0 13px 0 0" data-hover-color="#ffffff" data-color="#e6e6e6">
<a href="https://www.instagram.com/qodeinteractive/" target="_blank" rel="noopener noreferrer">
<span class="mkdf-image-icon">
<span aria-hidden="true" class="mkdf-icon-font-elegant social_instagram mkdf-icon-element" style="color: #e6e6e6;font-size:12px"></span> </span>
</a>
</span>
<span class="mkdf-icon-shortcode normal" style="margin: 0 15px 0 0" data-hover-color="#ffffff" data-color="#e6e6e6">
<a href="http://www.tripadvisor.com/" target="_blank" rel="noopener noreferrer">
 <span class="mkdf-image-icon">
<i class="mkdf-icon-font-awesome fa fa-tripadvisor mkdf-icon-element" style="color: #e6e6e6;font-size:14px"></i> </span>
</a>
</span>
</p>
</div>
</div> </div>
</div>
<div class="mkdf-position-right">
<div class="mkdf-position-right-inner">
<div id="text-7" class="widget widget_text mkdf-top-bar-widget"> <div class="textwidget">RESERVATIONS + 1-444-123-459
<span class="mkdf-icon-shortcode normal" style="margin: 0 7px 0 15px" data-hover-color="#ffffff" data-color="#e6e6e6">
<a href="https://piquant.qodeinteractive.com/reservations-contact-form/" target="_blank" rel="noopener noreferrer">
<span class="mkdf-image-icon">
<i class="mkdf-icon-simple-line-icon icon-calender mkdf-icon-element" style="color: #e6e6e6;font-size:12px"></i> </span>
</a>
</span>
BOOK NOW</div>
</div><div id="mkdf_side_area_opener-2" class="widget widget_mkdf_side_area_opener mkdf-top-bar-widget"> <a class="mkdf-side-menu-button-opener medium" href="javascript:void(0)">
<span aria-hidden="true" class="mkdf-icon-font-elegant icon_menu mkdf-side-area-icon"></span> </a>
</div> </div>
</div>
</div>
</div>
</div>
</div>
<header class="mkdf-page-header">
<div class="mkdf-menu-area">
<div class="mkdf-grid">
<div class="mkdf-vertical-align-containers">
<div class="mkdf-position-left">
<div class="mkdf-position-left-inner">
<div class="mkdf-logo-wrapper">
<a href="https://piquant.qodeinteractive.com/" style="height: 40px;">
<img class="mkdf-normal-logo" src="https://piquant.qodeinteractive.com/wp-content/uploads/2015/11/logo-normal.png" alt="logo" />
<img class="mkdf-dark-logo" src="https://piquant.qodeinteractive.com/wp-content/uploads/2015/11/logo-normal.png" alt="dark logo" /> <img class="mkdf-light-logo" src="https://piquant.qodeinteractive.com/wp-content/uploads/2015/11/logo-light.png" alt="light logo" /> </a>
</div>
</div>
</div>
<div class="mkdf-position-left mkdf-header-standard-menu-holder">
<div class="mkdf-position-left-inner">
<nav class="mkdf-main-menu mkdf-drop-down mkdf-default-nav">
<ul id="menu-top-menu" class="clearfix"><li id="nav-menu-item-207" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Home</span></span><span class="plus"></span></span></a>
<div class="second "><div class="inner"><ul>
<li id="nav-menu-item-9" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home "><a href="https://piquant.qodeinteractive.com/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Original</span></span><span class="plus"></span></span></a></li>
<li id="nav-menu-item-13" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/health-food-home/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Health Food</span></span><span class="plus"></span></span></a></li>
<li id="nav-menu-item-199" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/bar-cafe-home/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Bar &#038; Cafe<span class="mkdf-menu-featured-icon icon_star" aria-hidden="true"></span></span></span><span class="plus"></span></span></a></li>
<li id="nav-menu-item-339" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/restaurant-home/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Restaurant</span></span><span class="plus"></span></span></a></li>
<li id="nav-menu-item-345" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/bbq-home/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">BBQ Home</span></span><span class="plus"></span></span></a></li>
<li id="nav-menu-item-2051" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/fullscreen-home/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Fullscreen</span></span><span class="plus"></span></span></a></li>
</ul></div></div>
</li>
<li id="nav-menu-item-2335" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Reservations</span></span><span class="plus"></span></span></a>
<div class="second "><div class="inner"><ul>
<li id="nav-menu-item-2406" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/reservations-contact-form/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Contact Form</span></span><span class="plus"></span></span></a></li>
<li id="nav-menu-item-2407" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/reservations-open-table/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Open Table</span></span><span class="plus"></span></span></a></li>
</ul></div></div>
</li>
<li id="nav-menu-item-204" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Menu</span></span><span class="plus"></span></span></a>
<div class="second "><div class="inner"><ul>
<li id="nav-menu-item-1477" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/standard-list/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Standard List</span></span><span class="plus"></span></span></a></li>
<li id="nav-menu-item-1476" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/menu-gallery/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Menu Gallery</span></span><span class="plus"></span></span></a></li>
<li id="nav-menu-item-1629" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/gallery-list-combo/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Gallery &#038; List Combo</span></span><span class="plus"></span></span></a></li>
<li id="nav-menu-item-2076" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/list-with-image/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">List With Image</span></span><span class="plus"></span></span></a></li>
<li id="nav-menu-item-2266" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://piquant.qodeinteractive.com/menu-item/masala-spiced-chickpeas/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Single Menu Item</span></span><span class="plus"></span></span></a></li>
</ul></div></div>
</li>
<li id="nav-menu-item-203" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub wide"><a href="#" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Pages</span></span><span class="plus"></span></span></a>
<div class="second "><div class="inner"><ul>
<li id="nav-menu-item-211" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">About Pages</span></span><span class="plus"></span><i class="q_menu_arrow fa fa-angle-right"></i></span></a>
<ul>
<li id="nav-menu-item-598" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/about-us/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">About Us</span></span><span class="plus"></span></span></a></li>
<li id="nav-menu-item-646" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/our-story/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Our Story</span></span><span class="plus"></span></span></a></li>
<li id="nav-menu-item-557" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/our-services/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Our Services</span></span><span class="plus"></span></span></a></li>
<li id="nav-menu-item-727" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/what-we-offer/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">What We Offer</span></span><span class="plus"></span></span></a></li>
</ul>
</li>
<li id="nav-menu-item-212" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Info Pages</span></span><span class="plus"></span><i class="q_menu_arrow fa fa-angle-right"></i></span></a>
<ul>
<li id="nav-menu-item-709" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/meet-the-chefs/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Meet The Chefs</span></span><span class="plus"></span></span></a></li>
<li id="nav-menu-item-2072" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/food-gallery/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Food Gallery</span></span><span class="plus"></span></span></a></li>
<li id="nav-menu-item-757" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/contact-page/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Contact Page</span></span><span class="plus"></span></span></a></li>
<li id="nav-menu-item-792" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/contact-page-2/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Contact Page 2</span></span><span class="plus"></span></span></a></li>
</ul>
</li>
<li id="nav-menu-item-214" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Title Examples</span></span><span class="plus"></span><i class="q_menu_arrow fa fa-angle-right"></i></span></a>
<ul>
<li id="nav-menu-item-1138" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/system-title/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">System Title</span></span><span class="plus"></span></span></a></li>
<li id="nav-menu-item-1150" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/classic-title/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Classic Title</span></span><span class="plus"></span></span></a></li>
<li id="nav-menu-item-1599" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/overlapping-title/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Overlapping Title</span></span><span class="plus"></span></span></a></li>
<li id="nav-menu-item-1131" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/graphic-title/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Graphic Title</span></span><span class="plus"></span></span></a></li>
<li id="nav-menu-item-1605" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/parallax-title/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Parallax Title</span></span><span class="plus"></span></span></a></li>
</ul>
</li>
<li id="nav-menu-item-2339" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Today&#8217;s Specialty</span></span><span class="plus"></span><i class="q_menu_arrow fa fa-angle-right"></i></span></a><div class="widget widget_text"> <div class="textwidget"><div class="vc_empty_space" style="height: 4px"><span class="vc_empty_space_inner"></span></div>
<a style="padding: 0; margin: 0" href="https://piquant.qodeinteractive.com/menu-item/masala-spiced-chickpeas/"><img src="https://piquant.qodeinteractive.com/wp-content/uploads/2015/11/dropdown.jpg" alt="featured-post" /></a>
</div>
</div>
<ul>
<li id="nav-menu-item-2340" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://piquant.qodeinteractive.com/menu-item/masala-spiced-chickpeas/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">See The Recipe</span></span><span class="plus"></span></span></a></li>
</ul>
</li>
</ul></div></div>
</li>
<li id="nav-menu-item-205" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Blog</span></span><span class="plus"></span></span></a>
<div class="second "><div class="inner"><ul>
<li id="nav-menu-item-2338" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/latest-news/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Latest News</span></span><span class="plus"></span></span></a></li>
<li id="nav-menu-item-1488" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Post Types</span></span><span class="plus"></span><i class="q_menu_arrow fa fa-angle-right"></i></span></a>
<ul>
<li id="nav-menu-item-1489" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://piquant.qodeinteractive.com/grilled-chorizo-with-spicy-sauce/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Standard</span></span><span class="plus"></span></span></a></li>
<li id="nav-menu-item-1710" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://piquant.qodeinteractive.com/brazilian-burger-with-egg/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Gallery</span></span><span class="plus"></span></span></a></li>
<li id="nav-menu-item-1708" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://piquant.qodeinteractive.com/carne-asada-tacos/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Audio</span></span><span class="plus"></span></span></a></li>
<li id="nav-menu-item-1709" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://piquant.qodeinteractive.com/green-chile-and-chicken-stew/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Video</span></span><span class="plus"></span></span></a></li>
<li id="nav-menu-item-1490" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://piquant.qodeinteractive.com/julia-child/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Quote</span></span><span class="plus"></span></span></a></li>
<li id="nav-menu-item-2151" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://piquant.qodeinteractive.com/sweet-and-sour-pork-chops/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Link</span></span><span class="plus"></span></span></a></li>
</ul>
</li>
</ul></div></div>
</li>
<li id="nav-menu-item-206" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Shop</span></span><span class="plus"></span></span></a>
<div class="second "><div class="inner"><ul>
<li id="nav-menu-item-693" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/shop/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Shop With Sidebar</span></span><span class="plus"></span></span></a></li>
<li id="nav-menu-item-958" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/shop-three-columns/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Three Columns</span></span><span class="plus"></span></span></a></li>
<li id="nav-menu-item-971" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/shop-four-columns/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Four Columns</span></span><span class="plus"></span></span></a></li>
<li id="nav-menu-item-970" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/shop-four-columns-full-width/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Four Columns Full Width</span></span><span class="plus"></span></span></a></li>
<li id="nav-menu-item-944" class="menu-item menu-item-type-post_type menu-item-object-product "><a href="https://piquant.qodeinteractive.com/product/grilled-chorizo/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Single Product</span></span><span class="plus"></span></span></a></li>
</ul></div></div>
</li>
<li id="nav-menu-item-209" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub wide"><a href="#" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Elements</span></span><span class="plus"></span></span></a>
<div class="second  background_image" style="background-image:url(https://piquant.qodeinteractive.com/wp-content/uploads/2015/11/dropdown-backgorund1.jpg); background-size: cover; background-repeat: no-repeat; background-position: center;"><div class="inner"><ul>
<li id="nav-menu-item-805" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Typography &#038; Icons</span></span><span class="plus"></span><i class="q_menu_arrow fa fa-angle-right"></i></span></a>
<ul>
<li id="nav-menu-item-803" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/headings/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Headings</span></span><span class="plus"></span></span></a></li>
<li id="nav-menu-item-902" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/columns/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Columns</span></span><span class="plus"></span></span></a></li>
<li id="nav-menu-item-939" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/blockquotes/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Blockquotes</span></span><span class="plus"></span></span></a></li>
<li id="nav-menu-item-945" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/custom-fonts/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Custom Fonts</span></span><span class="plus"></span></span></a></li>
<li id="nav-menu-item-969" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/lists/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Lists</span></span><span class="plus"></span></span></a></li>
<li id="nav-menu-item-990" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/separators/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Separators</span></span><span class="plus"></span></span></a></li>
<li id="nav-menu-item-1014" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/icon/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Icon</span></span><span class="plus"></span></span></a></li>
</ul>
</li>
<li id="nav-menu-item-948" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Classic Elements</span></span><span class="plus"></span><i class="q_menu_arrow fa fa-angle-right"></i></span></a>
<ul>
<li id="nav-menu-item-1858" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/tabbed-gallery/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Tabbed Gallery<span class="mkdf-menu-featured-icon icon_star" aria-hidden="true"></span></span></span><span class="plus"></span></span></a></li>
<li id="nav-menu-item-2039" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/restaurant-menu/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Restaurant Menu<span class="mkdf-menu-featured-icon icon_star" aria-hidden="true"></span></span></span><span class="plus"></span></span></a></li>
<li id="nav-menu-item-1064" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/client-logo-carousel/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Client Logo Carousel</span></span><span class="plus"></span></span></a></li>
<li id="nav-menu-item-1297" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/blog-posts/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Blog Posts</span></span><span class="plus"></span></span></a></li>
<li id="nav-menu-item-1320" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/testimonials/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Testimonials</span></span><span class="plus"></span></span></a></li>
<li id="nav-menu-item-1697" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/meet-the-chefs/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Team</span></span><span class="plus"></span></span></a></li>
<li id="nav-menu-item-1061" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/google-maps/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Google Maps</span></span><span class="plus"></span></span></a></li>
</ul>
</li>
<li id="nav-menu-item-947" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">UI Elements</span></span><span class="plus"></span><i class="q_menu_arrow fa fa-angle-right"></i></span></a>
<ul>
<li id="nav-menu-item-1267" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/interface-colors/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Interface Colors</span></span><span class="plus"></span></span></a></li>
<li id="nav-menu-item-1069" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/buttons/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Buttons</span></span><span class="plus"></span></span></a></li>
<li id="nav-menu-item-1067" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/accordions/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Accordions</span></span><span class="plus"></span></span></a></li>
<li id="nav-menu-item-1066" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/tabs/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Tabs</span></span><span class="plus"></span></span></a></li>
<li id="nav-menu-item-1718" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/forms/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Forms<span class="mkdf-menu-featured-icon icon_star" aria-hidden="true"></span></span></span><span class="plus"></span></span></a></li>
<li id="nav-menu-item-1085" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/call-to-action/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Call To Action</span></span><span class="plus"></span></span></a></li>
</ul>
</li>
<li id="nav-menu-item-1347" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Graphic Elements</span></span><span class="plus"></span><i class="q_menu_arrow fa fa-angle-right"></i></span></a>
<ul>
<li id="nav-menu-item-2585" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/working-hours/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Working Hours</span></span><span class="plus"></span></span></a></li>
<li id="nav-menu-item-1811" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/interactive-banners/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Interactive Banners</span></span><span class="plus"></span></span></a></li>
<li id="nav-menu-item-1062" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/pricing-tables/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Pricing Tables</span></span><span class="plus"></span></span></a></li>
<li id="nav-menu-item-1354" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/counters/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Counters</span></span><span class="plus"></span></span></a></li>
<li id="nav-menu-item-1372" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/skill-bars/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Skill Bars</span></span><span class="plus"></span></span></a></li>
<li id="nav-menu-item-1386" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/pie-charts/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Pie Charts</span></span><span class="plus"></span></span></a></li>
<li id="nav-menu-item-1400" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/process/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Process</span></span><span class="plus"></span></span></a></li>
</ul>
</li>
</ul></div></div>
</li>
</ul></nav>
</div>
</div>
<div class="mkdf-position-right">
<div class="mkdf-position-right-inner">
<div id="search-3" class="widget widget_search mkdf-right-from-main-menu-widget"><form role="search" method="get" id="searchform" class="searchform" action="https://piquant.qodeinteractive.com/">
<div class="clearfix">
<input placeholder="Search..." type="text" value="" name="s" id="s" />
<input type="submit" id="searchsubmit" value="&#xf002;" />
</div>
</form></div><div id="mkdf_woocommerce_dropdown_cart-2" class="widget widget_mkdf_woocommerce_dropdown_cart mkdf-right-from-main-menu-widget"> <div class="mkdf-shopping-cart-outer">
<div class="mkdf-shopping-cart-inner">
<div class="mkdf-shopping-cart-header">
<a class="mkdf-header-cart" href="https://piquant.qodeinteractive.com/cart/">
<span class="mkdf-cart-label">Cart</span>
<span class="mkdf-cart-icon"></span>
<span class="mkdf-cart-count">0</span>
</a>
<div class="mkdf-shopping-cart-dropdown">
<ul>
<li class="mkdf-empty-cart">No products in the cart.</li>
</ul>
</div>
</div>
</div>
</div>
</div> </div>
</div>
</div>
</div>
</div>
<div class="mkdf-sticky-header">
<div class="mkdf-sticky-holder">
<div class="mkdf-grid">
<div class=" mkdf-vertical-align-containers">
<div class="mkdf-position-left">
<div class="mkdf-position-left-inner">
<div class="mkdf-logo-wrapper">
<a href="https://piquant.qodeinteractive.com/" style="height: 40px;">
<img class="mkdf-normal-logo" src="https://piquant.qodeinteractive.com/wp-content/uploads/2015/11/logo-light.png" alt="logo" />
<img class="mkdf-dark-logo" src="https://piquant.qodeinteractive.com/wp-content/uploads/2015/11/logo-normal.png" alt="dark logo" /> <img class="mkdf-light-logo" src="https://piquant.qodeinteractive.com/wp-content/uploads/2015/11/logo-light.png" alt="light logo" /> </a>
</div>
<nav class="mkdf-main-menu mkdf-drop-down mkdf-sticky-nav">
<ul id="menu-top-menu-1" class="clearfix"><li id="sticky-nav-menu-item-207" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Home</span></span><span class="plus"></span></span></a>
<div class="second "><div class="inner"><ul>
<li id="sticky-nav-menu-item-9" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home "><a href="https://piquant.qodeinteractive.com/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Original</span></span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-13" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/health-food-home/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Health Food</span></span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-199" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/bar-cafe-home/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Bar &#038; Cafe<span class="mkdf-menu-featured-icon icon_star" aria-hidden="true"></span></span></span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-339" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/restaurant-home/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Restaurant</span></span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-345" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/bbq-home/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">BBQ Home</span></span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-2051" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/fullscreen-home/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Fullscreen</span></span><span class="plus"></span></span></a></li>
</ul></div></div>
</li>
<li id="sticky-nav-menu-item-2335" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Reservations</span></span><span class="plus"></span></span></a>
<div class="second "><div class="inner"><ul>
<li id="sticky-nav-menu-item-2406" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/reservations-contact-form/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Contact Form</span></span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-2407" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/reservations-open-table/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Open Table</span></span><span class="plus"></span></span></a></li>
</ul></div></div>
</li>
<li id="sticky-nav-menu-item-204" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Menu</span></span><span class="plus"></span></span></a>
<div class="second "><div class="inner"><ul>
<li id="sticky-nav-menu-item-1477" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/standard-list/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Standard List</span></span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1476" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/menu-gallery/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Menu Gallery</span></span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1629" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/gallery-list-combo/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Gallery &#038; List Combo</span></span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-2076" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/list-with-image/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">List With Image</span></span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-2266" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://piquant.qodeinteractive.com/menu-item/masala-spiced-chickpeas/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Single Menu Item</span></span><span class="plus"></span></span></a></li>
</ul></div></div>
</li>
<li id="sticky-nav-menu-item-203" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub wide"><a href="#" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Pages</span></span><span class="plus"></span></span></a>
<div class="second "><div class="inner"><ul>
<li id="sticky-nav-menu-item-211" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">About Pages</span></span><span class="plus"></span><i class="q_menu_arrow fa fa-angle-right"></i></span></a>
<ul>
<li id="sticky-nav-menu-item-598" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/about-us/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">About Us</span></span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-646" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/our-story/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Our Story</span></span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-557" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/our-services/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Our Services</span></span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-727" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/what-we-offer/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">What We Offer</span></span><span class="plus"></span></span></a></li>
</ul>
</li>
<li id="sticky-nav-menu-item-212" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Info Pages</span></span><span class="plus"></span><i class="q_menu_arrow fa fa-angle-right"></i></span></a>
<ul>
<li id="sticky-nav-menu-item-709" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/meet-the-chefs/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Meet The Chefs</span></span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-2072" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/food-gallery/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Food Gallery</span></span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-757" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/contact-page/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Contact Page</span></span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-792" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/contact-page-2/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Contact Page 2</span></span><span class="plus"></span></span></a></li>
</ul>
</li>
<li id="sticky-nav-menu-item-214" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Title Examples</span></span><span class="plus"></span><i class="q_menu_arrow fa fa-angle-right"></i></span></a>
<ul>
<li id="sticky-nav-menu-item-1138" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/system-title/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">System Title</span></span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1150" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/classic-title/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Classic Title</span></span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1599" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/overlapping-title/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Overlapping Title</span></span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1131" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/graphic-title/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Graphic Title</span></span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1605" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/parallax-title/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Parallax Title</span></span><span class="plus"></span></span></a></li>
</ul>
</li>
<li id="sticky-nav-menu-item-2339" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Today&#8217;s Specialty</span></span><span class="plus"></span><i class="q_menu_arrow fa fa-angle-right"></i></span></a><div class="widget widget_text"> <div class="textwidget"><div class="vc_empty_space" style="height: 4px"><span class="vc_empty_space_inner"></span></div>
<a style="padding: 0; margin: 0" href="https://piquant.qodeinteractive.com/menu-item/masala-spiced-chickpeas/"><img src="https://piquant.qodeinteractive.com/wp-content/uploads/2015/11/dropdown.jpg" alt="featured-post" /></a>
</div>
</div>
<ul>
<li id="sticky-nav-menu-item-2340" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://piquant.qodeinteractive.com/menu-item/masala-spiced-chickpeas/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">See The Recipe</span></span><span class="plus"></span></span></a></li>
</ul>
</li>
</ul></div></div>
</li>
<li id="sticky-nav-menu-item-205" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Blog</span></span><span class="plus"></span></span></a>
<div class="second "><div class="inner"><ul>
<li id="sticky-nav-menu-item-2338" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/latest-news/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Latest News</span></span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1488" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Post Types</span></span><span class="plus"></span><i class="q_menu_arrow fa fa-angle-right"></i></span></a>
<ul>
<li id="sticky-nav-menu-item-1489" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://piquant.qodeinteractive.com/grilled-chorizo-with-spicy-sauce/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Standard</span></span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1710" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://piquant.qodeinteractive.com/brazilian-burger-with-egg/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Gallery</span></span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1708" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://piquant.qodeinteractive.com/carne-asada-tacos/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Audio</span></span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1709" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://piquant.qodeinteractive.com/green-chile-and-chicken-stew/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Video</span></span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1490" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://piquant.qodeinteractive.com/julia-child/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Quote</span></span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-2151" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://piquant.qodeinteractive.com/sweet-and-sour-pork-chops/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Link</span></span><span class="plus"></span></span></a></li>
</ul>
</li>
</ul></div></div>
</li>
<li id="sticky-nav-menu-item-206" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Shop</span></span><span class="plus"></span></span></a>
<div class="second "><div class="inner"><ul>
<li id="sticky-nav-menu-item-693" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/shop/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Shop With Sidebar</span></span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-958" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/shop-three-columns/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Three Columns</span></span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-971" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/shop-four-columns/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Four Columns</span></span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-970" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/shop-four-columns-full-width/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Four Columns Full Width</span></span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-944" class="menu-item menu-item-type-post_type menu-item-object-product "><a href="https://piquant.qodeinteractive.com/product/grilled-chorizo/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Single Product</span></span><span class="plus"></span></span></a></li>
</ul></div></div>
</li>
<li id="sticky-nav-menu-item-209" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub wide"><a href="#" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Elements</span></span><span class="plus"></span></span></a>
<div class="second  background_image" style="background-image:url(https://piquant.qodeinteractive.com/wp-content/uploads/2015/11/dropdown-backgorund1.jpg); background-size: cover; background-repeat: no-repeat; background-position: center;"><div class="inner"><ul>
<li id="sticky-nav-menu-item-805" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Typography &#038; Icons</span></span><span class="plus"></span><i class="q_menu_arrow fa fa-angle-right"></i></span></a>
<ul>
<li id="sticky-nav-menu-item-803" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/headings/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Headings</span></span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-902" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/columns/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Columns</span></span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-939" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/blockquotes/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Blockquotes</span></span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-945" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/custom-fonts/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Custom Fonts</span></span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-969" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/lists/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Lists</span></span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-990" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/separators/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Separators</span></span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1014" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/icon/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Icon</span></span><span class="plus"></span></span></a></li>
</ul>
</li>
<li id="sticky-nav-menu-item-948" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Classic Elements</span></span><span class="plus"></span><i class="q_menu_arrow fa fa-angle-right"></i></span></a>
<ul>
<li id="sticky-nav-menu-item-1858" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/tabbed-gallery/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Tabbed Gallery<span class="mkdf-menu-featured-icon icon_star" aria-hidden="true"></span></span></span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-2039" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/restaurant-menu/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Restaurant Menu<span class="mkdf-menu-featured-icon icon_star" aria-hidden="true"></span></span></span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1064" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/client-logo-carousel/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Client Logo Carousel</span></span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1297" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/blog-posts/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Blog Posts</span></span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1320" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/testimonials/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Testimonials</span></span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1697" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/meet-the-chefs/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Team</span></span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1061" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/google-maps/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Google Maps</span></span><span class="plus"></span></span></a></li>
</ul>
</li>
<li id="sticky-nav-menu-item-947" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">UI Elements</span></span><span class="plus"></span><i class="q_menu_arrow fa fa-angle-right"></i></span></a>
<ul>
<li id="sticky-nav-menu-item-1267" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/interface-colors/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Interface Colors</span></span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1069" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/buttons/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Buttons</span></span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1067" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/accordions/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Accordions</span></span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1066" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/tabs/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Tabs</span></span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1718" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/forms/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Forms<span class="mkdf-menu-featured-icon icon_star" aria-hidden="true"></span></span></span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1085" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/call-to-action/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Call To Action</span></span><span class="plus"></span></span></a></li>
</ul>
</li>
<li id="sticky-nav-menu-item-1347" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Graphic Elements</span></span><span class="plus"></span><i class="q_menu_arrow fa fa-angle-right"></i></span></a>
<ul>
<li id="sticky-nav-menu-item-2585" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/working-hours/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Working Hours</span></span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1811" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/interactive-banners/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Interactive Banners</span></span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1062" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/pricing-tables/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Pricing Tables</span></span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1354" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/counters/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Counters</span></span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1372" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/skill-bars/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Skill Bars</span></span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1386" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/pie-charts/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Pie Charts</span></span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1400" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/process/" class=""><span class="item_outer"><span class="item_inner"><span class="menu_icon_wrapper"><i class="menu_icon null fa"></i></span><span class="item_text">Process</span></span><span class="plus"></span></span></a></li>
</ul>
</li>
</ul></div></div>
</li>
</ul></nav>
</div>
</div>
<div class="mkdf-position-right">
<div class="mkdf-position-right-inner">
<div id="mkdf_side_area_opener-3" class="widget widget_mkdf_side_area_opener mkdf-sticky-right"> <a class="mkdf-side-menu-button-opener medium" href="javascript:void(0)">
<span aria-hidden="true" class="mkdf-icon-font-elegant icon_menu mkdf-side-area-icon"></span> </a>
</div> </div>
</div>
</div>
</div>
</div>
</div>
</header>
<header class="mkdf-mobile-header">
<div class="mkdf-mobile-header-inner">
<div class="mkdf-mobile-header-holder">
<div class="mkdf-grid">
<div class="mkdf-vertical-align-containers">
<div class="mkdf-mobile-menu-opener">
<a href="javascript:void(0)">
<span class="mkdf-mobile-opener-icon-holder">
 <i class="mkdf-icon-font-awesome fa fa-bars "></i> </span>
</a>
</div>
<div class="mkdf-position-center">
<div class="mkdf-position-center-inner">
<div class="mkdf-mobile-logo-wrapper">
<a href="https://piquant.qodeinteractive.com/" style="height: 40px">
<img src="https://piquant.qodeinteractive.com/wp-content/uploads/2015/11/logo-normal.png" alt="mobile-logo" />
</a>
</div>
</div>
</div>
<div class="mkdf-position-right">
<div class="mkdf-position-right-inner">
</div>
</div>
</div> 
</div>
</div>
<nav class="mkdf-mobile-nav">
<div class="mkdf-grid">
<ul id="menu-top-menu-2" class=""><li id="mobile-menu-item-207" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><h4><span>Home</span></h4><span class="mobile_arrow"><i class="mkdf-sub-arrow fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-9" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home "><a href="https://piquant.qodeinteractive.com/" class=""><span>Original</span></a></li>
<li id="mobile-menu-item-13" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/health-food-home/" class=""><span>Health Food</span></a></li>
<li id="mobile-menu-item-199" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/bar-cafe-home/" class=""><span>Bar &#038; Cafe</span></a></li>
<li id="mobile-menu-item-339" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/restaurant-home/" class=""><span>Restaurant</span></a></li>
<li id="mobile-menu-item-345" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/bbq-home/" class=""><span>BBQ Home</span></a></li>
<li id="mobile-menu-item-2051" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/fullscreen-home/" class=""><span>Fullscreen</span></a></li>
</ul>
</li>
<li id="mobile-menu-item-2335" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><h4><span>Reservations</span></h4><span class="mobile_arrow"><i class="mkdf-sub-arrow fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-2406" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/reservations-contact-form/" class=""><span>Contact Form</span></a></li>
<li id="mobile-menu-item-2407" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/reservations-open-table/" class=""><span>Open Table</span></a></li>
</ul>
</li>
<li id="mobile-menu-item-204" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><h4><span>Menu</span></h4><span class="mobile_arrow"><i class="mkdf-sub-arrow fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-1477" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/standard-list/" class=""><span>Standard List</span></a></li>
<li id="mobile-menu-item-1476" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/menu-gallery/" class=""><span>Menu Gallery</span></a></li>
<li id="mobile-menu-item-1629" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/gallery-list-combo/" class=""><span>Gallery &#038; List Combo</span></a></li>
<li id="mobile-menu-item-2076" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/list-with-image/" class=""><span>List With Image</span></a></li>
<li id="mobile-menu-item-2266" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://piquant.qodeinteractive.com/menu-item/masala-spiced-chickpeas/" class=""><span>Single Menu Item</span></a></li>
</ul>
</li>
<li id="mobile-menu-item-203" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><h4><span>Pages</span></h4><span class="mobile_arrow"><i class="mkdf-sub-arrow fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-211" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><a href="#" class=""><span>About Pages</span></a><span class="mobile_arrow"><i class="mkdf-sub-arrow fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-598" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/about-us/" class=""><span>About Us</span></a></li>
<li id="mobile-menu-item-646" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/our-story/" class=""><span>Our Story</span></a></li>
<li id="mobile-menu-item-557" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/our-services/" class=""><span>Our Services</span></a></li>
<li id="mobile-menu-item-727" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/what-we-offer/" class=""><span>What We Offer</span></a></li>
</ul>
</li>
<li id="mobile-menu-item-212" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><a href="#" class=""><span>Info Pages</span></a><span class="mobile_arrow"><i class="mkdf-sub-arrow fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-709" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/meet-the-chefs/" class=""><span>Meet The Chefs</span></a></li>
<li id="mobile-menu-item-2072" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/food-gallery/" class=""><span>Food Gallery</span></a></li>
<li id="mobile-menu-item-757" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/contact-page/" class=""><span>Contact Page</span></a></li>
<li id="mobile-menu-item-792" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/contact-page-2/" class=""><span>Contact Page 2</span></a></li>
</ul>
</li>
<li id="mobile-menu-item-214" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><a href="#" class=""><span>Title Examples</span></a><span class="mobile_arrow"><i class="mkdf-sub-arrow fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-1138" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/system-title/" class=""><span>System Title</span></a></li>
<li id="mobile-menu-item-1150" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/classic-title/" class=""><span>Classic Title</span></a></li>
<li id="mobile-menu-item-1599" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/overlapping-title/" class=""><span>Overlapping Title</span></a></li>
<li id="mobile-menu-item-1131" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/graphic-title/" class=""><span>Graphic Title</span></a></li>
<li id="mobile-menu-item-1605" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/parallax-title/" class=""><span>Parallax Title</span></a></li>
</ul>
</li>
<li id="mobile-menu-item-2339" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><a href="#" class=""><span>Today&#8217;s Specialty</span></a><span class="mobile_arrow"><i class="mkdf-sub-arrow fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-2340" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://piquant.qodeinteractive.com/menu-item/masala-spiced-chickpeas/" class=""><span>See The Recipe</span></a></li>
</ul>
</li>
</ul>
</li>
<li id="mobile-menu-item-205" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><h4><span>Blog</span></h4><span class="mobile_arrow"><i class="mkdf-sub-arrow fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-2338" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/latest-news/" class=""><span>Latest News</span></a></li>
<li id="mobile-menu-item-1488" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><h4><span>Post Types</span></h4><span class="mobile_arrow"><i class="mkdf-sub-arrow fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-1489" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://piquant.qodeinteractive.com/grilled-chorizo-with-spicy-sauce/" class=""><span>Standard</span></a></li>
<li id="mobile-menu-item-1710" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://piquant.qodeinteractive.com/brazilian-burger-with-egg/" class=""><span>Gallery</span></a></li>
<li id="mobile-menu-item-1708" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://piquant.qodeinteractive.com/carne-asada-tacos/" class=""><span>Audio</span></a></li>
<li id="mobile-menu-item-1709" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://piquant.qodeinteractive.com/green-chile-and-chicken-stew/" class=""><span>Video</span></a></li>
<li id="mobile-menu-item-1490" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://piquant.qodeinteractive.com/julia-child/" class=""><span>Quote</span></a></li>
<li id="mobile-menu-item-2151" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://piquant.qodeinteractive.com/sweet-and-sour-pork-chops/" class=""><span>Link</span></a></li>
</ul>
</li>
</ul>
</li>
<li id="mobile-menu-item-206" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><h4><span>Shop</span></h4><span class="mobile_arrow"><i class="mkdf-sub-arrow fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-693" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/shop/" class=""><span>Shop With Sidebar</span></a></li>
<li id="mobile-menu-item-958" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/shop-three-columns/" class=""><span>Three Columns</span></a></li>
<li id="mobile-menu-item-971" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/shop-four-columns/" class=""><span>Four Columns</span></a></li>
<li id="mobile-menu-item-970" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/shop-four-columns-full-width/" class=""><span>Four Columns Full Width</span></a></li>
<li id="mobile-menu-item-944" class="menu-item menu-item-type-post_type menu-item-object-product "><a href="https://piquant.qodeinteractive.com/product/grilled-chorizo/" class=""><span>Single Product</span></a></li>
</ul>
</li>
<li id="mobile-menu-item-209" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><h4><span>Elements</span></h4><span class="mobile_arrow"><i class="mkdf-sub-arrow fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-805" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><h4><span>Typography &#038; Icons</span></h4><span class="mobile_arrow"><i class="mkdf-sub-arrow fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-803" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/headings/" class=""><span>Headings</span></a></li>
<li id="mobile-menu-item-902" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/columns/" class=""><span>Columns</span></a></li>
<li id="mobile-menu-item-939" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/blockquotes/" class=""><span>Blockquotes</span></a></li>
<li id="mobile-menu-item-945" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/custom-fonts/" class=""><span>Custom Fonts</span></a></li>
<li id="mobile-menu-item-969" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/lists/" class=""><span>Lists</span></a></li>
<li id="mobile-menu-item-990" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/separators/" class=""><span>Separators</span></a></li>
<li id="mobile-menu-item-1014" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/icon/" class=""><span>Icon</span></a></li>
</ul>
</li>
<li id="mobile-menu-item-948" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><h4><span>Classic Elements</span></h4><span class="mobile_arrow"><i class="mkdf-sub-arrow fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-1858" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/tabbed-gallery/" class=""><span>Tabbed Gallery</span></a></li>
<li id="mobile-menu-item-2039" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/restaurant-menu/" class=""><span>Restaurant Menu</span></a></li>
<li id="mobile-menu-item-1064" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/client-logo-carousel/" class=""><span>Client Logo Carousel</span></a></li>
<li id="mobile-menu-item-1297" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/blog-posts/" class=""><span>Blog Posts</span></a></li>
<li id="mobile-menu-item-1320" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/testimonials/" class=""><span>Testimonials</span></a></li>
<li id="mobile-menu-item-1697" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/meet-the-chefs/" class=""><span>Team</span></a></li>
<li id="mobile-menu-item-1061" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/google-maps/" class=""><span>Google Maps</span></a></li>
</ul>
</li>
<li id="mobile-menu-item-947" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><h4><span>UI Elements</span></h4><span class="mobile_arrow"><i class="mkdf-sub-arrow fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-1267" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/interface-colors/" class=""><span>Interface Colors</span></a></li>
<li id="mobile-menu-item-1069" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/buttons/" class=""><span>Buttons</span></a></li>
<li id="mobile-menu-item-1067" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/accordions/" class=""><span>Accordions</span></a></li>
<li id="mobile-menu-item-1066" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/tabs/" class=""><span>Tabs</span></a></li>
<li id="mobile-menu-item-1718" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/forms/" class=""><span>Forms</span></a></li>
<li id="mobile-menu-item-1085" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/call-to-action/" class=""><span>Call To Action</span></a></li>
</ul>
</li>
<li id="mobile-menu-item-1347" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><h4><span>Graphic Elements</span></h4><span class="mobile_arrow"><i class="mkdf-sub-arrow fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-2585" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/working-hours/" class=""><span>Working Hours</span></a></li>
<li id="mobile-menu-item-1811" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/interactive-banners/" class=""><span>Interactive Banners</span></a></li>
<li id="mobile-menu-item-1062" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/pricing-tables/" class=""><span>Pricing Tables</span></a></li>
<li id="mobile-menu-item-1354" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/counters/" class=""><span>Counters</span></a></li>
<li id="mobile-menu-item-1372" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/skill-bars/" class=""><span>Skill Bars</span></a></li>
<li id="mobile-menu-item-1386" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/pie-charts/" class=""><span>Pie Charts</span></a></li>
<li id="mobile-menu-item-1400" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://piquant.qodeinteractive.com/process/" class=""><span>Process</span></a></li>
</ul>
</li>
</ul>
</li>
</ul> </div>
</nav>
</div>
</header> 
<a id='mkdf-back-to-top' href='#'>
<span class="mkdf-back-to-top-text">Top</span>
<span aria-hidden="true" class="arrow_carrot-up"></span>
</a>
<div class="mkdf-content">
<div class="mkdf-content-inner">
<div class="mkdf-title mkdf-standard-type mkdf-content-left-alignment mkdf-animation-no" style="height:57px;" data-height="57">
<div class="mkdf-title-image"></div>
<div class="mkdf-title-holder" style="height:57px;">
<div class="mkdf-container clearfix">
<div class="mkdf-container-inner">
<div class="mkdf-title-subtitle-holder" style="">
<div class="mkdf-title-subtitle-holder-inner">
 <h1><span>404 - Page not found</span></h1>
<div class="mkdf-breadcrumbs-holder"> <div class="mkdf-breadcrumbs"><div class="mkdf-breadcrumbs-inner"><a href="https://piquant.qodeinteractive.com/"><span class="mkdf-icon-font-elegant icon_house "></span></a><span class="mkdf-delimiter">&nbsp;/&nbsp;</span><span class="mkdf-current">Error 404</span></div></div></div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="mkdf-container">
<div class="mkdf-container-inner mkdf-404-page">
<div class="mkdf-page-not-found">
<h2>
Page you are looking is not found </h2>
<h4>
The page you are looking for does not exist. It may have been moved, or removed altogether. Perhaps you can return back to the site&#039;s homepage and see if you can find what you are looking for. </h4>
<a href="https://piquant.qodeinteractive.com/" target="_self" class="mkdf-btn mkdf-btn-medium mkdf-btn-solid">
<span class="mkdf-btn-text">Back to Home Page</span>
</a> </div>
</div>
</div>
</div> 
</div> 
<footer>
<div class="mkdf-footer-inner clearfix">
<div class="mkdf-footer-top-holder">
<div class="mkdf-footer-top ">
<div class="mkdf-container">
<div class="mkdf-container-inner">
<div class="mkdf-four-columns clearfix">
<div class="mkdf-four-columns-inner">
<div class="mkdf-column">
<div class="mkdf-column-inner">
<div id="text-2" class="widget mkdf-footer-column-1 widget_text"> <div class="textwidget"><a href="https://piquant.qodeinteractive.com/"><img src="https://piquant.qodeinteractive.com/wp-content/uploads/2015/11/logo-footer.png" alt="logo"></a>
<div class="vc_empty_space" style="height: 7px"><span class="vc_empty_space_inner"></span></div>
Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.
<div class="vc_empty_space" style="height: 15px"><span class="vc_empty_space_inner"></span></div>
<div class="mkdf-icon-list-item">
<div class="mkdf-icon-list-icon-holder">
<div class="mkdf-icon-list-icon-holder-inner clearfix">
<span aria-hidden="true" class="mkdf-icon-font-elegant icon_mail mkdf-icon-list-item-icon-elem" style="color:#ffffff;font-size:13px"></span> </div>
</div>
<p style="color:#ffffff;font-size:12px"> <a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="7c0c150d091d12083c0d131819151208190e1d1f08150a19521f1311">[email&#160;protected]</a></p>
</div>
<div class="mkdf-icon-list-item">
<div class="mkdf-icon-list-icon-holder">
<div class="mkdf-icon-list-icon-holder-inner clearfix">
<span aria-hidden="true" class="mkdf-icon-font-elegant icon_phone mkdf-icon-list-item-icon-elem" style="color:#ffffff;font-size:13px"></span> </div>
</div>
<p style="color:#ffffff;font-size:12px"> 1-444-123-4559</p>
</div>
<div class="mkdf-icon-list-item">
<div class="mkdf-icon-list-icon-holder">
<div class="mkdf-icon-list-icon-holder-inner clearfix">
<span aria-hidden="true" class="mkdf-icon-font-elegant icon_pin mkdf-icon-list-item-icon-elem" style="color:#ffffff;font-size:13px"></span> </div>
</div>
<p style="color:#ffffff;font-size:12px"> Raymond Boulevard 224, New York</p>
</div>
</div>
</div> </div>
</div>
<div class="mkdf-column">
<div class="mkdf-column-inner">
<div id="recent-posts-3" class="widget mkdf-footer-column-2 widget_recent_entries"> <h4 class="mkdf-footer-widget-title">Recent Posts</h4> <ul>
<li>
<a href="https://piquant.qodeinteractive.com/chicken-tinga-nachos-2/">Chicken Tinga Nachos</a>
</li>
<li>
<a href="https://piquant.qodeinteractive.com/sweet-and-sour-pork-chops-2/">Sweet and Sour Pork Chops</a>
</li>
<li>
<a href="https://piquant.qodeinteractive.com/green-chile-and-chicken-stew-2/">Green Chile And Chicken Stew</a>
</li>
<li>
<a href="https://piquant.qodeinteractive.com/pecan-pie-macarons-2/">Pecan Pie Macarons</a>
</li>
</ul>
</div><div id="text-3" class="widget mkdf-footer-column-2 widget_text"> <div class="textwidget"><div class="vc_empty_space" style="height: 10px"><span class="vc_empty_space_inner"></span></div></div>
</div> </div>
</div>
<div class="mkdf-column">
<div class="mkdf-column-inner">
<div id="mkdf_instagram_widget-2" class="widget mkdf-footer-column-3 widget_mkdf_instagram_widget"><h4 class="mkdf-footer-widget-title">Instagram</h4> <ul class="mkdf-instagram-feed clearfix mkdf-col-4 ">
<li>
<div class="mkdf-instagram-item-holder">
<a href="https://www.instagram.com/p/Bot2gyln1nU/" target="_blank">
<img src="https://scontent-fml2-1.cdninstagram.com/v/t51.2885-15/43093965_1916827798621723_1291503193552138689_n.jpg?_nc_cat=102&ccb=1-5&_nc_sid=8ae9d6&_nc_ohc=WEDJ5S05RXcAX-Wuvl6&_nc_ht=scontent-fml2-1.cdninstagram.com&edm=ANo9K5cEAAAA&oh=2b5b6b6e03ab4270e74d32a3c075e39f&oe=6177FB56" alt="" />
<div class="mkdf-instagram-overlay">
<div class="mkdf-instagram-overlay-inner">
<div class="mkdf-instagram-overlay-inner2">
<span class="overlay-icon social-instagram"></span>
</div>
</div>
</div>
</a>
</div>
</li>
<li>
<div class="mkdf-instagram-item-holder">
<a href="https://www.instagram.com/p/Bot2fQjHRGS/" target="_blank">
<img src="https://scontent-fml2-1.cdninstagram.com/v/t51.2885-15/42691144_246754759348315_254487827641566810_n.jpg?_nc_cat=108&ccb=1-5&_nc_sid=8ae9d6&_nc_ohc=WpL4O2PICEkAX8ulCvx&_nc_ht=scontent-fml2-1.cdninstagram.com&edm=ANo9K5cEAAAA&oh=d479ea351d4e3ca1a6e012a6af77eb1f&oe=6178F3C7" alt="" />
<div class="mkdf-instagram-overlay">
<div class="mkdf-instagram-overlay-inner">
<div class="mkdf-instagram-overlay-inner2">
<span class="overlay-icon social-instagram"></span>
</div>
</div>
</div>
</a>
</div>
</li>
<li>
<div class="mkdf-instagram-item-holder">
<a href="https://www.instagram.com/p/Bot2dsuHQfZ/" target="_blank">
<img src="https://scontent-fml2-1.cdninstagram.com/v/t51.2885-15/42595106_705884559780745_1978305445669430907_n.jpg?_nc_cat=110&ccb=1-5&_nc_sid=8ae9d6&_nc_ohc=B7SiWCk30zUAX9NaDPn&_nc_ht=scontent-fml2-1.cdninstagram.com&edm=ANo9K5cEAAAA&oh=4afac2ab47f0c26e285e5ee58d915045&oe=61782879" alt="" />
<div class="mkdf-instagram-overlay">
<div class="mkdf-instagram-overlay-inner">
<div class="mkdf-instagram-overlay-inner2">
<span class="overlay-icon social-instagram"></span>
</div>
</div>
</div>
</a>
</div>
</li>
<li>
<div class="mkdf-instagram-item-holder">
<a href="https://www.instagram.com/p/Bot2born_cU/" target="_blank">
<img src="https://scontent-fml2-1.cdninstagram.com/v/t51.2885-15/42080438_2240447655979056_4351826486246174451_n.jpg?_nc_cat=111&ccb=1-5&_nc_sid=8ae9d6&_nc_ohc=xg_VM-eAi_IAX8HPYee&_nc_ht=scontent-fml2-1.cdninstagram.com&edm=ANo9K5cEAAAA&oh=a4e213a68bfda5a84dabfb9ae12de198&oe=6178C2B7" alt="" />
<div class="mkdf-instagram-overlay">
<div class="mkdf-instagram-overlay-inner">
<div class="mkdf-instagram-overlay-inner2">
<span class="overlay-icon social-instagram"></span>
</div>
</div>
</div>
</a>
</div>
</li>
<li>
<div class="mkdf-instagram-item-holder">
<a href="https://www.instagram.com/p/Bot2Z8mnvlg/" target="_blank">
<img src="https://scontent-fml2-1.cdninstagram.com/v/t51.2885-15/42388782_306112229994288_8631028034354049856_n.jpg?_nc_cat=100&ccb=1-5&_nc_sid=8ae9d6&_nc_ohc=v7giTEGntGYAX9hgXEZ&_nc_ht=scontent-fml2-1.cdninstagram.com&edm=ANo9K5cEAAAA&oh=7f2436bc4a336749d726bd8e9a8b754e&oe=6178E274" alt="" />
<div class="mkdf-instagram-overlay">
<div class="mkdf-instagram-overlay-inner">
<div class="mkdf-instagram-overlay-inner2">
<span class="overlay-icon social-instagram"></span>
</div>
</div>
</div>
</a>
</div>
</li>
<li>
<div class="mkdf-instagram-item-holder">
<a href="https://www.instagram.com/p/Bot2X7kndPr/" target="_blank">
<img src="https://scontent-fml2-1.cdninstagram.com/v/t51.2885-15/42340160_890571594486891_7605612084773657126_n.jpg?_nc_cat=109&ccb=1-5&_nc_sid=8ae9d6&_nc_ohc=ZDR2h67FciYAX8hN-Me&_nc_ht=scontent-fml2-1.cdninstagram.com&edm=ANo9K5cEAAAA&oh=83afe2c0e267f505e79ec712285b47ef&oe=61791F1C" alt="" />
<div class="mkdf-instagram-overlay">
<div class="mkdf-instagram-overlay-inner">
<div class="mkdf-instagram-overlay-inner2">
<span class="overlay-icon social-instagram"></span>
</div>
</div>
</div>
</a>
</div>
</li>
<li>
<div class="mkdf-instagram-item-holder">
<a href="https://www.instagram.com/p/Bot2WGoHJsh/" target="_blank">
<img src="https://scontent-fml2-1.cdninstagram.com/v/t51.2885-15/42961687_241191326560991_5174934017545570844_n.jpg?_nc_cat=104&ccb=1-5&_nc_sid=8ae9d6&_nc_ohc=uHOBQToAiDEAX8oZ2eh&_nc_ht=scontent-fml2-1.cdninstagram.com&edm=ANo9K5cEAAAA&oh=61b4a5221101f82b229592ca1fdc8d5f&oe=617815AB" alt="" />
<div class="mkdf-instagram-overlay">
<div class="mkdf-instagram-overlay-inner">
<div class="mkdf-instagram-overlay-inner2">
<span class="overlay-icon social-instagram"></span>
</div>
</div>
</div>
</a>
</div>
</li>
<li>
<div class="mkdf-instagram-item-holder">
<a href="https://www.instagram.com/p/Bot2US1HS96/" target="_blank">
<img src="https://scontent-fml2-1.cdninstagram.com/v/t51.2885-15/42711549_175183406697281_4230654296084625043_n.jpg?_nc_cat=100&ccb=1-5&_nc_sid=8ae9d6&_nc_ohc=rwNV7GXwU78AX8ZAE2e&_nc_oc=AQmn5Qxal-PvidFRl6zyeWCDfz_BkAtPDUWjK6CmEWiNKDoE8mhE8vFY46TNIvATqgg&_nc_ht=scontent-fml2-1.cdninstagram.com&edm=ANo9K5cEAAAA&oh=20e451a343566ff247356e9bbf8e6d66&oe=61795634" alt="" />
<div class="mkdf-instagram-overlay">
<div class="mkdf-instagram-overlay-inner">
<div class="mkdf-instagram-overlay-inner2">
<span class="overlay-icon social-instagram"></span>
</div>
</div>
</div>
</a>
</div>
</li>
</ul>
</div> </div>
</div>
<div class="mkdf-column">
<div class="mkdf-column-inner">
<div id="mkdf_twitter_widget-2" class="widget mkdf-footer-column-4 widget_mkdf_twitter_widget"><h4 class="mkdf-footer-widget-title">Twitter Feed</h4> <ul class="mkdf_twitter_widget">
<li>
<div class="twitter_icon">
<span aria-hidden="true" class="social_twitter"></span>
</div>
<div class="mkdf_tweet_text">
Even though the functions.php file is one of the most important #WordPress files for webmasters, it often goes unde… <a target="_blank" href="https://t.co/3WLiOS9eJz">https://t.co/3WLiOS9eJz</a> </div>
</li>
</ul>
</div> </div>
</div>
</div>
</div> </div>
</div>
</div>
</div>
<div class="mkdf-footer-bottom-holder">
<div class="mkdf-footer-bottom-holder-inner">
<div class="mkdf-container">
<div class="mkdf-container-inner">
<div class="mkdf-two-columns-50-50 clearfix">
<div class="mkdf-two-columns-50-50-inner">
<div class="mkdf-column">
<div class="mkdf-column-inner">
<div id="text-4" class="widget mkdf-footer-bottom-left widget_text"> <div class="textwidget">© 2015 <a style="color: #ffffff;" href="https://qodeinteractive.com/" target="_blank" rel="noopener noreferrer">Qode Interactive</a>, All Rights Reserved</div>
</div> </div>
</div>
<div class="mkdf-column">
<div class="mkdf-column-inner">
<div id="text-5" class="widget mkdf-footer-bottom-left widget_text"> <div class="textwidget"><p>Follow Us
<span class="mkdf-icon-shortcode normal" style="margin: 0 15px 0 15px" data-hover-color="#fcf033" data-color="#ffffff">
<a href="https://www.facebook.com/QodeInteractive/" target="_blank" rel="noopener noreferrer">
<span class="mkdf-image-icon">
<span aria-hidden="true" class="mkdf-icon-font-elegant social_facebook mkdf-icon-element" style="color: #ffffff;font-size:12px"></span> </span>
</a>
</span>
<span class="mkdf-icon-shortcode normal" style="margin: 0 15px 0 0" data-hover-color="#fcf033" data-color="#ffffff">
<a href="https://twitter.com/QodeInteractive" target="_blank" rel="noopener noreferrer">
<span class="mkdf-image-icon">
<span aria-hidden="true" class="mkdf-icon-font-elegant social_twitter mkdf-icon-element" style="color: #ffffff;font-size:12px"></span> </span>
</a>
</span>
<span class="mkdf-icon-shortcode normal" style="margin: 0 13px 0 0" data-hover-color="#fcf033" data-color="#ffffff">
<a href="https://www.instagram.com/qodeinteractive/" target="_blank" rel="noopener noreferrer">
<span class="mkdf-image-icon">
<span aria-hidden="true" class="mkdf-icon-font-elegant social_instagram mkdf-icon-element" style="color: #ffffff;font-size:12px"></span> </span>
</a>
</span>
<span class="mkdf-icon-shortcode normal" style="margin: 0 15px 0 0" data-hover-color="#fcf033" data-color="#ffffff">
<a href="http://www.tripadvisor.com/" target="_blank" rel="noopener noreferrer">
<span class="mkdf-image-icon">
<i class="mkdf-icon-font-awesome fa fa-tripadvisor mkdf-icon-element" style="color: #ffffff;font-size:14px"></i> </span>
</a>
</span>
</p>
</div>
</div> </div>
</div>
</div>
</div> </div>
</div>
</div>
</div>
</div>
</footer>
</div> 
</div> 
<div class="rbt-toolbar" data-theme="Piquant" data-featured="" data-button-position="30%" data-button-horizontal="right" data-button-alt="no"></div>

<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-KTQ2BTD"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script type='text/javascript'>
/* <![CDATA[ */
var wpcf7 = {"apiSettings":{"root":"https:\/\/piquant.qodeinteractive.com\/wp-json\/contact-form-7\/v1","namespace":"contact-form-7\/v1"},"cached":"1"};
/* ]]> */
</script>
<script src="https://piquant.qodeinteractive.com/wp-content/cache/minify/0fef6.js"></script>
<script type='text/javascript' src='https://export.qodethemes.com/_toolbar/assets/js/rbt-modules.js?ver=5.2.12'></script>
<script src="https://piquant.qodeinteractive.com/wp-content/cache/minify/6d18f.js"></script>
<script type='text/javascript'>
/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/TweenLite.js?wc-ajax=%%endpoint%%"};
/* ]]> */
</script>
<script src="https://piquant.qodeinteractive.com/wp-content/cache/minify/3c2c7.js"></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_cart_fragments_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/TweenLite.js?wc-ajax=%%endpoint%%","fragment_name":"wc_fragments"};
/* ]]> */
</script>
<script src="https://piquant.qodeinteractive.com/wp-content/cache/minify/bf1c6.js"></script>
<script type='text/javascript' src='https://maps.googleapis.com/maps/api/js?key=AIzaSyDfSe2XNvOAkZSNiqFZNdJ2kMYJAcp-REk&#038;ver=5.2.12'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var mkdfGlobalVars = {"vars":{"mkdfAddForAdminBar":0,"mkdfElementAppearAmount":-150,"mkdfFinishedMessage":"No more posts","mkdfMessage":"Loading new posts...","mkdfTopBarHeight":51,"mkdfStickyHeaderHeight":60,"mkdfStickyHeaderTransparencyHeight":60,"mkdfLogoAreaHeight":0,"mkdfMenuAreaHeight":146,"mkdfMobileHeaderHeight":100}};
var mkdfPerPageVars = {"vars":{"mkdfStickyScrollAmount":0,"mkdfHeaderTransparencyHeight":0}};
/* ]]> */
</script>
<script src="https://piquant.qodeinteractive.com/wp-content/cache/minify/643c5.js"></script>
<script type='text/javascript'>
/* <![CDATA[ */
var mkdfLike = {"ajaxurl":"https:\/\/piquant.qodeinteractive.com\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script src="https://piquant.qodeinteractive.com/wp-content/cache/minify/5a656.js"></script>
<script type='text/javascript'>
jQuery(document).ready(function(jQuery){jQuery.datepicker.setDefaults({"closeText":"Close","currentText":"Today","monthNames":["January","February","March","April","May","June","July","August","September","October","November","December"],"monthNamesShort":["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],"nextText":"Next","prevText":"Previous","dayNames":["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],"dayNamesShort":["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],"dayNamesMin":["S","M","T","W","T","F","S"],"dateFormat":"MM d, yy","firstDay":1,"isRTL":false});});
</script>
<script src="https://piquant.qodeinteractive.com/wp-content/cache/minify/38968.js"></script>
</body>
</html>
